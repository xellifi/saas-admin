import React from 'react';
import { useQuery } from '@tanstack/react-query';
import axios from 'axios';
import { Package, ShoppingCart, DollarSign, AlertTriangle } from 'lucide-react';
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend,
} from 'chart.js';
import { Bar } from 'react-chartjs-2';

ChartJS.register(
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend
);

const fetchDashboardStats = async () => {
    const { data } = await axios.get('/api/addons/online-store/admin/dashboard');
    if (!data.success) throw new Error(data.error);
    return data;
};

export default function Dashboard() {
    const { data, isLoading, error } = useQuery({
        queryKey: ['store-dashboard'],
        queryFn: fetchDashboardStats
    });

    if (isLoading) return <div className="p-8 text-center text-gray-500">Loading store dashboard...</div>;
    if (error) return <div className="p-8 text-center text-red-500">Error loading dashboard</div>;

    const { stats, alerts, recentOrders } = data;

    const chartData = {
        labels: ['Products', 'Orders'],
        datasets: [
            {
                label: 'Count',
                data: [stats.products, stats.orders],
                backgroundColor: ['rgba(59, 130, 246, 0.8)', 'rgba(16, 185, 129, 0.8)'],
                borderColor: ['rgba(59, 130, 246, 1)', 'rgba(16, 185, 129, 1)'],
                borderWidth: 1,
            },
        ],
    };

    const chartOptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: { position: 'top' },
            title: { display: false },
        },
    };

    return (
        <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-800">Store Dashboard</h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white rounded-lg border p-6 flex items-center">
                    <div className="p-3 rounded-full bg-blue-100 text-blue-600 mr-4">
                        <DollarSign className="w-6 h-6" />
                    </div>
                    <div>
                        <p className="text-sm text-gray-500 font-medium">Total Revenue</p>
                        <p className="text-2xl font-bold text-gray-900">${parseFloat(stats.revenue || 0).toFixed(2)}</p>
                    </div>
                </div>
                <div className="bg-white rounded-lg border p-6 flex items-center">
                    <div className="p-3 rounded-full bg-green-100 text-green-600 mr-4">
                        <ShoppingCart className="w-6 h-6" />
                    </div>
                    <div>
                        <p className="text-sm text-gray-500 font-medium">Total Orders</p>
                        <p className="text-2xl font-bold text-gray-900">{stats.orders}</p>
                    </div>
                </div>
                <div className="bg-white rounded-lg border p-6 flex items-center">
                    <div className="p-3 rounded-full bg-purple-100 text-purple-600 mr-4">
                        <Package className="w-6 h-6" />
                    </div>
                    <div>
                        <p className="text-sm text-gray-500 font-medium">Total Products</p>
                        <p className="text-2xl font-bold text-gray-900">{stats.products}</p>
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white rounded-lg border p-6">
                    <h3 className="text-lg font-semibold text-gray-800 mb-4">Overview</h3>
                    <div className="h-64 relative">
                        <Bar options={chartOptions} data={chartData} />
                    </div>
                </div>

                <div className="bg-white rounded-lg border p-6">
                    <h3 className="text-lg font-semibold text-gray-800 border-b pb-2 mb-4">Recent Orders</h3>
                    {recentOrders?.length === 0 ? (
                        <p className="text-gray-500 text-sm">No recent orders found.</p>
                    ) : (
                        <div className="space-y-4">
                            {recentOrders?.map(order => (
                                <div key={order.id} className="flex justify-between items-center border-b pb-2 last:border-0 last:pb-0">
                                    <div>
                                        <p className="font-medium text-gray-800">{order.order_number}</p>
                                        <p className="text-xs text-gray-500">{order.customer_name}</p>
                                    </div>
                                    <div className="text-right">
                                        <p className="font-semibold text-gray-900">${parseFloat(order.total).toFixed(2)}</p>
                                        <span className="text-xs px-2 py-1 rounded-full bg-blue-100 text-blue-800 capitalize">
                                            {order.status}
                                        </span>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>

            {alerts && alerts.length > 0 && (
                <div className="bg-red-50 border-l-4 border-red-500 p-4 rounded-md">
                    <div className="flex">
                        <div className="flex-shrink-0">
                            <AlertTriangle className="h-5 w-5 text-red-500" />
                        </div>
                        <div className="ml-3">
                            <h3 className="text-sm font-medium text-red-800">Low Inventory Alerts</h3>
                            <div className="mt-2 text-sm text-red-700">
                                <ul className="list-disc pl-5 space-y-1">
                                    {alerts.map(prod => (
                                        <li key={prod.id}>{prod.name} (Only {prod.inventory} left)</li>
                                    ))}
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
