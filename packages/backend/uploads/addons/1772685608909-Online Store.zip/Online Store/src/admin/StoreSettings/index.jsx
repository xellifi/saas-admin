import React, { useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import axios from 'axios';
import { useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import { Save, Store } from 'lucide-react';

const fetchSettings = async () => {
    const { data } = await axios.get('/api/addons/online-store/admin/settings');
    return data.settings || {};
};

export default function StoreSettings() {
    const queryClient = useQueryClient();
    const { register, handleSubmit, reset } = useForm();

    const { data: settings = {}, isLoading } = useQuery({
        queryKey: ['store-settings'],
        queryFn: fetchSettings
    });

    useEffect(() => {
        if (settings) {
            reset(settings);
        }
    }, [settings, reset]);

    const updateMutation = useMutation({
        mutationFn: (data) => axios.put('/api/addons/online-store/admin/settings', data),
        onSuccess: () => {
            queryClient.invalidateQueries(['store-settings']);
            toast.success('Store settings saved successfully!');
        },
        onError: () => toast.error('Failed to save settings.')
    });

    const onSubmit = (data) => {
        updateMutation.mutate(data);
    };

    if (isLoading) {
        return <div className="p-8 text-center text-gray-500">Loading store configuration...</div>;
    }

    return (
        <div className="space-y-6 max-w-4xl mx-auto">
            <h2 className="text-2xl font-bold text-gray-800 flex items-center">
                <Store className="w-6 h-6 mr-2" /> Store Settings
            </h2>

            <div className="bg-white rounded-lg shadow border p-6">
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="md:col-span-2">
                            <label className="block text-sm font-medium text-gray-700">Store Name</label>
                            <input
                                {...register('store_name', { required: true })}
                                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2 border"
                            />
                            <p className="mt-1 text-sm text-gray-500">This is the name that will appear on your storefront and receipts.</p>
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-gray-700">Currency Code</label>
                            <select
                                {...register('currency')}
                                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2 border"
                            >
                                <option value="USD">USD ($)</option>
                                <option value="EUR">EUR (€)</option>
                                <option value="GBP">GBP (£)</option>
                                <option value="CAD">CAD ($)</option>
                                <option value="AUD">AUD ($)</option>
                            </select>
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-gray-700">Tax Rate (%)</label>
                            <input
                                type="number"
                                step="0.01"
                                {...register('tax_rate', { valueAsNumber: true })}
                                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2 border"
                            />
                        </div>

                        <div className="md:col-span-2">
                            <label className="block text-sm font-medium text-gray-700">Flat Rate Shipping Cost ($)</label>
                            <input
                                type="number"
                                step="0.01"
                                {...register('shipping_flat_rate', { valueAsNumber: true })}
                                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2 border"
                            />
                            <p className="mt-1 text-sm text-gray-500">Apply a standard flat rate shipping cost to all orders.</p>
                        </div>
                    </div>

                    <div className="flex justify-end pt-4 border-t">
                        <button
                            type="submit"
                            className="bg-blue-600 text-white px-6 py-2 rounded-md flex items-center hover:bg-blue-700 disabled:opacity-50"
                            disabled={updateMutation.isLoading}
                        >
                            <Save className="w-5 h-5 mr-2" />
                            {updateMutation.isLoading ? 'Saving...' : 'Save Settings'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
}
