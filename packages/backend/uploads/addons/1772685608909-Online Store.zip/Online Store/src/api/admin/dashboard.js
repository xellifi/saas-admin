import { executeQuery } from '../db.js';

export default async function dashboardPlugin(fastify, options) {
    fastify.get('/', async (request, reply) => {
        try {
            const accountId = request.query.accountId || (request.user && request.user.id);
            if (!accountId) return reply.status(400).send({ error: 'accountId is required' });

            // Stats
            const products = await executeQuery('SELECT COUNT(*) as count FROM online_store_products WHERE account_id = ?', [accountId]);
            const orders = await executeQuery('SELECT COUNT(*) as count FROM online_store_orders WHERE account_id = ?', [accountId]);
            const revenue = await executeQuery('SELECT SUM(total) as sum FROM online_store_orders WHERE account_id = ? AND status = ?', [accountId, 'paid']);
            const inventoryAlerts = await executeQuery('SELECT * FROM online_store_products WHERE account_id = ? AND inventory < 10 LIMIT 5', [accountId]);
            const recentOrders = await executeQuery('SELECT * FROM online_store_orders WHERE account_id = ? ORDER BY created_at DESC LIMIT 5', [accountId]);

            return {
                success: true,
                stats: {
                    products: products[0]?.count || 0,
                    orders: orders[0]?.count || 0,
                    revenue: revenue[0]?.sum || 0
                },
                alerts: inventoryAlerts,
                recentOrders
            };
        } catch (error) {
            fastify.log.error(error);
            return reply.status(500).send({ error: 'Failed to fetch dashboard stats' });
        }
    });
}
