import { executeQuery } from '../db.js';

export default async function productsPlugin(fastify, options) {
    // GET all products for an account
    fastify.get('/', async (request, reply) => {
        try {
            const accountId = request.query.accountId || (request.user && request.user.id);
            if (!accountId) return reply.status(400).send({ error: 'accountId is required' });

            const products = await executeQuery(
                'SELECT * FROM online_store_products WHERE account_id = ? ORDER BY created_at DESC',
                [accountId]
            );
            return { success: true, products };
        } catch (error) {
            fastify.log.error(error);
            return reply.status(500).send({ error: 'Failed to fetch products' });
        }
    });

    // POST create a product
    fastify.post('/', async (request, reply) => {
        try {
            const { accountId, name, description, price, status, inventory } = request.body;
            const finalAccountId = accountId || (request.user && request.user.id);
            if (!finalAccountId) return reply.status(400).send({ error: 'accountId is required' });

            const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-') + '-' + Date.now();
            const images = JSON.stringify(request.body.images || []);

            const result = await executeQuery(
                `INSERT INTO online_store_products (account_id, name, slug, description, price, images, status, inventory) 
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
                [finalAccountId, name, slug, description || '', price || 0, images, status || 'draft', inventory || 0]
            );

            return reply.status(201).send({ success: true, id: result.insertId, message: 'Product created' });
        } catch (error) {
            fastify.log.error(error);
            return reply.status(500).send({ error: 'Failed to create product' });
        }
    });

    // PUT update a product
    fastify.put('/:id', async (request, reply) => {
        try {
            const productId = request.params.id;
            const { name, description, price, status, inventory } = request.body;
            const images = request.body.images ? JSON.stringify(request.body.images) : null;

            let updateFields = [];
            let params = [];

            if (name !== undefined) { updateFields.push('name = ?'); params.push(name); }
            if (description !== undefined) { updateFields.push('description = ?'); params.push(description); }
            if (price !== undefined) { updateFields.push('price = ?'); params.push(price); }
            if (status !== undefined) { updateFields.push('status = ?'); params.push(status); }
            if (inventory !== undefined) { updateFields.push('inventory = ?'); params.push(inventory); }
            if (images !== null) { updateFields.push('images = ?'); params.push(images); }

            if (updateFields.length === 0) return { success: true };

            params.push(productId);
            await executeQuery(`UPDATE online_store_products SET ${updateFields.join(', ')} WHERE id = ?`, params);

            return { success: true, message: 'Product updated' };
        } catch (error) {
            fastify.log.error(error);
            return reply.status(500).send({ error: 'Failed to update product' });
        }
    });

    // DELETE a product
    fastify.delete('/:id', async (request, reply) => {
        try {
            const productId = request.params.id;
            await executeQuery('DELETE FROM online_store_products WHERE id = ?', [productId]);
            return { success: true, message: 'Product deleted' };
        } catch (error) {
            fastify.log.error(error);
            return reply.status(500).send({ error: 'Failed to delete product' });
        }
    });
}
