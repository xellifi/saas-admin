import { executeQuery } from '../db.js';

export default async function settingsPlugin(fastify, options) {
    fastify.get('/', async (request, reply) => {
        try {
            const accountId = request.query.accountId || (request.user && request.user.id);
            if (!accountId) return reply.status(400).send({ error: 'accountId is required' });

            const settings = await executeQuery(
                'SELECT * FROM online_store_settings WHERE account_id = ?',
                [accountId]
            );

            if (!settings || settings.length === 0) {
                return {
                    success: true,
                    settings: {
                        store_name: 'My Store',
                        currency: 'USD',
                        tax_rate: 0,
                        shipping_flat_rate: 0
                    }
                };
            }

            return { success: true, settings: settings[0] };
        } catch (error) {
            fastify.log.error(error);
            return {
                success: true,
                settings: {
                    store_name: 'My Store',
                    currency: 'USD',
                    tax_rate: 0,
                    shipping_flat_rate: 0
                }
            };
        }
    });

    fastify.put('/', async (request, reply) => {
        try {
            const accountId = request.body.accountId || (request.user && request.user.id);
            if (!accountId) return reply.status(400).send({ error: 'accountId is required' });

            const { store_name, currency, tax_rate, shipping_flat_rate } = request.body;

            const existing = await executeQuery('SELECT id FROM online_store_settings WHERE account_id = ?', [accountId]);

            if (existing && existing.length > 0) {
                await executeQuery(
                    'UPDATE online_store_settings SET store_name = ?, currency = ?, tax_rate = ?, shipping_flat_rate = ? WHERE account_id = ?',
                    [store_name, currency, tax_rate, shipping_flat_rate, accountId]
                );
            } else {
                await executeQuery(
                    'INSERT INTO online_store_settings (account_id, store_name, currency, tax_rate, shipping_flat_rate) VALUES (?, ?, ?, ?, ?)',
                    [accountId, store_name, currency, tax_rate, shipping_flat_rate]
                );
            }

            return { success: true, message: 'Settings updated successfully' };
        } catch (error) {
            fastify.log.error(error);
            return reply.status(500).send({ error: 'Failed to update store settings' });
        }
    });
}
