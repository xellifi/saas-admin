import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import axios from 'axios';
import { Search, Eye, FileText, Send } from 'lucide-react';
import toast from 'react-hot-toast';

const fetchOrders = async () => {
    const { data } = await axios.get('/api/addons/online-store/admin/orders');
    return data.orders || [];
};

export default function Orders() {
    const queryClient = useQueryClient();
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedOrder, setSelectedOrder] = useState(null);

    const { data: orders = [], isLoading } = useQuery({
        queryKey: ['store-orders'],
        queryFn: fetchOrders
    });

    const updateStatusMutation = useMutation({
        mutationFn: ({ id, status }) => axios.put(`/api/addons/online-store/admin/orders/${id}/status`, { status }),
        onSuccess: () => {
            queryClient.invalidateQueries(['store-orders']);
            toast.success('Order status updated');
        },
        onError: () => toast.error('Failed to update status')
    });

    const filteredOrders = orders.filter(o =>
        o.order_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
        o.customer_name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const getStatusColor = (status) => {
        switch (status) {
            case 'paid': return 'bg-blue-100 text-blue-800';
            case 'shipped': return 'bg-indigo-100 text-indigo-800';
            case 'delivered': return 'bg-green-100 text-green-800';
            case 'cancelled': return 'bg-red-100 text-red-800';
            default: return 'bg-yellow-100 text-yellow-800';
        }
    };

    return (
        <div className="space-y-6 flex flex-col h-full">
            <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-gray-800">Orders Management</h2>
            </div>

            <div className="bg-white rounded-lg shadow overflow-hidden flex-grow flex">
                {/* Orders List */}
                <div className={`w-full ${selectedOrder ? 'hidden md:block md:w-1/2 lg:w-2/3 border-r' : ''}`}>
                    <div className="p-4 border-b">
                        <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <Search className="h-5 w-5 text-gray-400" />
                            </div>
                            <input
                                type="text"
                                placeholder="Search orders or customers..."
                                className="pl-10 w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                                value={searchTerm}
                                onChange={e => setSearchTerm(e.target.value)}
                            />
                        </div>
                    </div>

                    <div className="overflow-x-auto">
                        {isLoading ? (
                            <div className="p-8 text-center text-gray-500">Loading orders...</div>
                        ) : (
                            <table className="min-w-full divide-y divide-gray-200">
                                <thead className="bg-gray-50">
                                    <tr>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Order#</th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Customer</th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Total</th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                        <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Actions</th>
                                    </tr>
                                </thead>
                                <tbody className="bg-white divide-y divide-gray-200">
                                    {filteredOrders.map((order) => (
                                        <tr
                                            key={order.id}
                                            className={`hover:bg-gray-50 cursor-pointer ${selectedOrder?.id === order.id ? 'bg-blue-50' : ''}`}
                                            onClick={() => setSelectedOrder(order)}
                                        >
                                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{order.order_number}</td>
                                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                <div>{order.customer_name}</div>
                                                <div className="text-xs text-gray-400">{order.customer_email}</div>
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-gray-900">${parseFloat(order.total).toFixed(2)}</td>
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full capitalize ${getStatusColor(order.status)}`}>
                                                    {order.status}
                                                </span>
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap text-right text-sm">
                                                <button className="text-gray-400 hover:text-blue-600">
                                                    <Eye className="w-5 h-5" />
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        )}
                    </div>
                </div>

                {/* Order Details Panel */}
                {selectedOrder && (
                    <div className="w-full md:w-1/2 lg:w-1/3 bg-gray-50 border-l overflow-y-auto max-h-[80vh]">
                        <div className="p-6">
                            <div className="flex justify-between items-center mb-6">
                                <h3 className="text-lg font-bold">Order Details</h3>
                                <button onClick={() => setSelectedOrder(null)} className="text-gray-500 hover:text-gray-700 md:hidden">Close</button>
                            </div>

                            <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
                                <div className="flex justify-between items-center mb-4">
                                    <span className="text-sm text-gray-500">Order ID:</span>
                                    <span className="font-medium">{selectedOrder.order_number}</span>
                                </div>
                                <div className="flex justify-between items-center mb-4">
                                    <span className="text-sm text-gray-500">Status:</span>
                                    <select
                                        value={selectedOrder.status}
                                        onChange={(e) => {
                                            updateStatusMutation.mutate({ id: selectedOrder.id, status: e.target.value });
                                            setSelectedOrder({ ...selectedOrder, status: e.target.value });
                                        }}
                                        className="rounded border-gray-300 text-sm focus:ring-blue-500 focus:border-blue-500 font-semibold"
                                    >
                                        <option value="pending">Pending</option>
                                        <option value="paid">Paid</option>
                                        <option value="shipped">Shipped</option>
                                        <option value="delivered">Delivered</option>
                                        <option value="cancelled">Cancelled</option>
                                    </select>
                                </div>
                                <div className="flex justify-between items-center">
                                    <span className="text-sm text-gray-500">Date:</span>
                                    <span className="text-sm">{new Date(selectedOrder.created_at).toLocaleString()}</span>
                                </div>
                            </div>

                            <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
                                <h4 className="font-semibold mb-2">Customer</h4>
                                <p className="text-sm">{selectedOrder.customer_name}</p>
                                <p className="text-sm text-gray-500">{selectedOrder.customer_email}</p>
                            </div>

                            <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
                                <h4 className="font-semibold mb-3">Items</h4>
                                <div className="space-y-3">
                                    {(() => {
                                        try {
                                            const items = typeof selectedOrder.items === 'string' ? JSON.parse(selectedOrder.items) : selectedOrder.items;
                                            return items.map((item, i) => (
                                                <div key={i} className="flex justify-between text-sm">
                                                    <span>Product #{item.productId} x {item.qty}</span>
                                                    <span>${(item.price * item.qty).toFixed(2)}</span>
                                                </div>
                                            ));
                                        } catch (e) {
                                            return <div className="text-sm text-red-500">Invalid items data</div>;
                                        }
                                    })()}
                                </div>
                                <div className="border-t mt-4 pt-3 flex justify-between font-bold">
                                    <span>Total</span>
                                    <span>${parseFloat(selectedOrder.total).toFixed(2)}</span>
                                </div>
                            </div>

                            <div className="flex space-x-2">
                                <a
                                    href={`/store/${selectedOrder.account_id}/invoice/${selectedOrder.id}`}
                                    target="_blank"
                                    rel="noreferrer"
                                    className="flex-1 bg-white border border-gray-300 text-gray-700 py-2 rounded-md hover:bg-gray-50 flex items-center justify-center font-medium text-sm"
                                >
                                    <FileText className="w-4 h-4 mr-2" /> View Invoice
                                </a>
                                <button className="flex-1 bg-blue-600 border border-transparent text-white py-2 rounded-md hover:bg-blue-700 flex items-center justify-center font-medium text-sm">
                                    <Send className="w-4 h-4 mr-2" /> Resend Link
                                </button>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}
