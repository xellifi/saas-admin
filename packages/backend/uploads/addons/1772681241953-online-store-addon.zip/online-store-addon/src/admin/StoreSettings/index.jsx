import React, { useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import axios from 'axios';
import { useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import { Save, Globe, Code } from 'lucide-react';

const fetchSettings = async () => {
    const { data } = await axios.get('/api/addons/online-store/admin/settings');
    return data.settings || {};
};

export default function StoreSettings({ accountId = 1 }) {
    const queryClient = useQueryClient();
    const { register, handleSubmit, reset } = useForm();

    const { data: settings = {}, isLoading } = useQuery({
        queryKey: ['store-settings'],
        queryFn: fetchSettings,
        onSuccess: (data) => reset(data)
    });

    useEffect(() => {
        if (Object.keys(settings).length > 0) {
            reset({
                storeName: settings.store_name,
                customDomain: settings.custom_domain,
                currency: settings.currency,
                taxRate: settings.tax_rate,
                shippingFlatRate: settings.shipping_flat_rate,
                enabled: settings.enabled === 1 || settings.enabled === true
            });
        }
    }, [settings, reset]);

    const updateMutation = useMutation({
        mutationFn: (data) => axios.put('/api/addons/online-store/admin/settings', data),
        onSuccess: () => {
            queryClient.invalidateQueries(['store-settings']);
            toast.success('Settings saved successfully');
        },
        onError: () => toast.error('Failed to save settings')
    });

    const onSubmit = (data) => {
        updateMutation.mutate(data);
    };

    if (isLoading) return <div className="p-8 text-center text-gray-500">Loading settings...</div>;

    const storeUrl = settings.custom_domain
        ? `https://${settings.custom_domain}`
        : `${window.location.origin}/store/${accountId}`;

    return (
        <div className="space-y-6 max-w-4xl">
            <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-gray-800">Store Settings</h2>
            </div>

            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">

                {/* General Settings */}
                <div className="bg-white rounded-lg shadow overflow-hidden">
                    <div className="p-4 border-b bg-gray-50">
                        <h3 className="font-semibold text-gray-800">General Information</h3>
                    </div>
                    <div className="p-6 space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700">Store Name</label>
                                <input type="text" {...register('storeName', { required: true })} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500" />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700">Currency</label>
                                <select {...register('currency')} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500">
                                    <option value="USD">USD ($)</option>
                                    <option value="EUR">EUR (€)</option>
                                    <option value="GBP">GBP (£)</option>
                                    <option value="CAD">CAD ($)</option>
                                </select>
                            </div>
                        </div>

                        <div>
                            <label className="flex items-center space-x-3">
                                <input type="checkbox" {...register('enabled')} className="form-checkbox h-5 w-5 text-blue-600 border-gray-300 rounded" />
                                <span className="text-sm font-medium text-gray-700">Enable Public Store</span>
                            </label>
                            <p className="text-xs text-gray-500 mt-1 ml-8">If disabled, the public store URL will show a "Coming Soon" or "Maintenance" page.</p>
                        </div>
                    </div>
                </div>

                {/* Domain & Access */}
                <div className="bg-white rounded-lg shadow overflow-hidden">
                    <div className="p-4 border-b bg-gray-50">
                        <h3 className="font-semibold text-gray-800">Domain & Access</h3>
                    </div>
                    <div className="p-6 space-y-6">
                        <div>
                            <label className="block text-sm font-medium text-gray-700">Custom Domain (Optional)</label>
                            <div className="mt-1 flex rounded-md shadow-sm">
                                <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-gray-300 bg-gray-50 text-gray-500 text-sm">
                                    https://
                                </span>
                                <input type="text" placeholder="shop.yourdomain.com" {...register('customDomain')} className="flex-1 block w-full rounded-none rounded-r-md border-gray-300 focus:ring-blue-500 focus:border-blue-500" />
                            </div>
                            <p className="text-xs text-gray-500 mt-2">Point a CNAME record to <code>domains.saasdashboard.com</code> to use a custom domain.</p>
                        </div>

                        <div className="bg-blue-50 rounded-lg p-4 border border-blue-100 pb-5">
                            <h4 className="flex items-center font-medium text-blue-900 mb-2">
                                <Globe className="w-4 h-4 mr-2" /> Your Store Link
                            </h4>
                            <a href={storeUrl} target="_blank" rel="noreferrer" className="text-blue-600 hover:underline font-medium break-all">{storeUrl}</a>
                        </div>

                        <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                            <h4 className="flex items-center font-medium text-gray-900 mb-2">
                                <Code className="w-4 h-4 mr-2" /> Embed on your website
                            </h4>
                            <p className="text-xs text-gray-600 mb-2">Copy this iframe snippet to embed the store on any existing website.</p>
                            <code className="block p-3 bg-gray-800 text-gray-100 rounded text-xs overflow-x-auto">
                                {`<iframe src="${storeUrl}" width="100%" height="800" frameborder="0"></iframe>`}
                            </code>
                        </div>
                    </div>
                </div>

                {/* Checkout & Taxes */}
                <div className="bg-white rounded-lg shadow overflow-hidden">
                    <div className="p-4 border-b bg-gray-50">
                        <h3 className="font-semibold text-gray-800">Checkout & Taxes</h3>
                    </div>
                    <div className="p-6 space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700">Tax Rate (%)</label>
                                <input type="number" step="0.01" {...register('taxRate', { valueAsNumber: true })} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500" />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700">Flat Shipping Rate ($)</label>
                                <input type="number" step="0.01" {...register('shippingFlatRate', { valueAsNumber: true })} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500" />
                            </div>
                        </div>
                    </div>
                </div>

                <div className="flex justify-end pt-4">
                    <button
                        type="submit"
                        disabled={updateMutation.isLoading}
                        className="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 flex items-center font-medium shadow-sm transition-colors"
                    >
                        {updateMutation.isLoading ? 'Saving...' : <><Save className="w-5 h-5 mr-2" /> Save Settings</>}
                    </button>
                </div>
            </form>
        </div>
    );
}
