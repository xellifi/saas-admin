import { executeQuery } from '../db.js';

export default async function settingsPlugin(fastify, options) {
    fastify.get('/', async (request, reply) => {
        try {
            const accountId = request.query.accountId || (request.user && request.user.id);
            if (!accountId) return reply.status(400).send({ error: 'accountId is required' });

            const settings = await executeQuery('SELECT * FROM online_store_settings WHERE account_id = ?', [accountId]);
            return { success: true, settings: settings[0] || {} };
        } catch (error) {
            fastify.log.error(error);
            return reply.status(500).send({ error: 'Failed to fetch settings' });
        }
    });

    fastify.put('/', async (request, reply) => {
        try {
            const accountId = request.body.accountId || (request.user && request.user.id);
            if (!accountId) return reply.status(400).send({ error: 'accountId is required' });

            const { storeName, customDomain, currency, taxRate, shippingFlatRate, enabled } = request.body;

            await executeQuery(
                `INSERT INTO online_store_settings (account_id, store_name, custom_domain, currency, tax_rate, shipping_flat_rate, enabled)
                 VALUES (?, ?, ?, ?, ?, ?, ?)
                 ON DUPLICATE KEY UPDATE 
                 store_name = VALUES(store_name),
                 custom_domain = VALUES(custom_domain),
                 currency = VALUES(currency),
                 tax_rate = VALUES(tax_rate),
                 shipping_flat_rate = VALUES(shipping_flat_rate),
                 enabled = VALUES(enabled)`,
                [accountId, storeName, customDomain, currency || 'USD', taxRate || 0, shippingFlatRate || 0, enabled !== undefined ? enabled : true]
            );

            return { success: true, message: 'Settings saved' };
        } catch (error) {
            fastify.log.error(error);
            return reply.status(500).send({ error: 'Failed to save settings' });
        }
    });
}
